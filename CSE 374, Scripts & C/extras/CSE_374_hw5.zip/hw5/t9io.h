#pragma once

void interactions(struct node*);

struct node* treefromfile(char*);	
